#ifndef REDPITAYA_H
#define REDPITAYA_H

#ifdef __cplusplus
extern "C" {
#endif

// I2C Buses
#define I2C_0 0
//#define I2C_2 2
#define MAX_I2C_PINS 1

#ifdef __cplusplus
}
#endif

#endif
