#ifndef _SETUP_H
#define _SETUP_H



/*** API *****************************************************************************************/

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Signals initialization
 */
void wyliodrinSetup();

#ifdef __cplusplus
}
#endif

/*************************************************************************************************/



#endif /* _SETUP_H */
